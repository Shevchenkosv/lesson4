<?php

namespace GeekBrains\LevelTwo\Http\Actions\Comments;

class DeleteComment
{

}