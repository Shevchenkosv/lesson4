<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class PostNotFoundException extends AppException
{

}