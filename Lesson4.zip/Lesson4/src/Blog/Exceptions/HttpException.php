<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class HttpException extends AppException
{

}