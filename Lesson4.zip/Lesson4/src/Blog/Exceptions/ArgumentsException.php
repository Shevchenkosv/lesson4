<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class ArgumentsException extends AppException
{

}