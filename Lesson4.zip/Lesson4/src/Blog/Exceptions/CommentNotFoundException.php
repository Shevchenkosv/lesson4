<?php

namespace GeekBrains\LevelTwo\Blog\Exceptions;

class CommentNotFoundException extends AppException
{

}