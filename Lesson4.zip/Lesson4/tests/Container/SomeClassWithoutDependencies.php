<?php

namespace GeekBrains\Blog\UnitTests\Container;

class SomeClassWithoutDependencies
{

}